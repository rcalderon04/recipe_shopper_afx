// Configuration
// No backend needed - all parsing done in JavaScript!

// DOM elements
let recipeUrlInput;
let addToCartBtn;
let getCurrentUrlBtn;
let statusDiv;
let ingredientList;
let recipeTitle;
let noRecipe;
let urlInputGroup;
let storeModal;
let changeStoreBtn;
let closeModalBtn;
let selectedStoreLogo;
let selectedStoreName;
let selectedStore = 'wholefoods'; // Default store

// Store configuration
const STORES = {
    wholefoods: {
        name: 'Whole Foods',
        logo: 'wholefoods_logo.png'
    },
    amazonfresh: {
        name: 'Amazon Fresh',
        logo: 'amazonfresh_logo.png'
    }
};

// State
let currentIngredients = null;
let currentRecipeTitle = '';

// Per-tab recipe cache
const tabRecipeCache = new Map();

// Listen for tab change messages from background
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'TAB_CHANGED' || message.type === 'TAB_UPDATED') {
        autoParseCurrentPage();
    }
});

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Get DOM elements
    recipeUrlInput = document.getElementById('recipeUrl');
    addToCartBtn = document.getElementById('addToCart');
    getCurrentUrlBtn = document.getElementById('getCurrentUrl');
    statusDiv = document.getElementById('status');
    ingredientList = document.getElementById('ingredientList');
    recipeTitle = document.getElementById('recipeTitle');
    noRecipe = document.getElementById('noRecipe');
    urlInputGroup = document.getElementById('urlInputGroup');
    storeModal = document.getElementById('storeModal');
    changeStoreBtn = document.getElementById('changeStoreBtn');
    closeModalBtn = document.getElementById('closeModalBtn');
    selectedStoreLogo = document.getElementById('selectedStoreLogo');
    selectedStoreName = document.getElementById('selectedStoreName');

    // Load saved store preference
    chrome.storage.local.get(['preferredStore'], (result) => {
        if (result.preferredStore) {
            selectedStore = result.preferredStore;
            updateStoreCard();
        }
    });

    // Modal event listeners
    if (changeStoreBtn) {
        changeStoreBtn.addEventListener('click', openStoreModal);
    }

    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeStoreModal);
    }

    // Click outside modal to close
    if (storeModal) {
        storeModal.addEventListener('click', (e) => {
            if (e.target === storeModal) {
                closeStoreModal();
            }
        });
    }

    // Store option click handlers
    document.querySelectorAll('.store-option').forEach(option => {
        option.addEventListener('click', function () {
            const store = this.dataset.store;
            selectStore(store);
            closeStoreModal();
        });
    });

    // Add event listeners
    addToCartBtn.addEventListener('click', handleAddToCart);
    getCurrentUrlBtn.addEventListener('click', handleGetCurrentUrl);

    // Allow Enter key to submit
    recipeUrlInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleAddToCart();
        }
    });

    // Click on "no recipe" message to show URL input
    noRecipe.addEventListener('click', () => {
        showUrlInput();
    });

    // Auto-parse current page on open
    autoParseCurrentPage();
});

function openStoreModal() {
    if (storeModal) {
        storeModal.classList.remove('hidden');
        updateStoreOptions();
    }
}

function closeStoreModal() {
    if (storeModal) {
        storeModal.classList.add('hidden');
    }
}

function selectStore(store) {
    selectedStore = store;
    updateStoreCard();
    updateStoreOptions();
    chrome.storage.local.set({ preferredStore: store });
}

function updateStoreCard() {
    const storeConfig = STORES[selectedStore];
    if (selectedStoreLogo && selectedStoreName && storeConfig) {
        selectedStoreLogo.src = storeConfig.logo;
        selectedStoreName.textContent = storeConfig.name;
    }
}

function updateStoreOptions() {
    document.querySelectorAll('.store-option').forEach(option => {
        const isSelected = option.dataset.store === selectedStore;
        option.classList.toggle('selected', isSelected);
    });
}

/**
 * Gets the HTML content of a tab via script injection
 * This bypasses CORS restrictions
 */
async function getTabHtml(tabId) {
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: () => document.documentElement.outerHTML
        });
        if (results && results[0]) {
            return results[0].result;
        }
    } catch (e) {
        console.error('Script injection failed:', e);
    }
    return null;
}

async function autoParseCurrentPage() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!tab || !tab.url || tab.url.startsWith('chrome://')) {
            showNoRecipe();
            return;
        }

        const cached = tabRecipeCache.get(tab.id);
        if (cached && cached.url === tab.url) {
            currentIngredients = cached.ingredients;
            currentRecipeTitle = cached.title;
            displayIngredients(cached.ingredients, cached.title);
            recipeUrlInput.value = tab.url;
            return;
        }

        showLoadingState();

        // Get HTML via script injection (bypasses CORS)
        const html = await getTabHtml(tab.id);

        if (!html) {
            console.log('Failed to retrieve HTML from tab');
            showNoRecipe();
            return;
        }

        // Use JavaScript parser
        const parser = new RecipeParser();
        const data = await parser.parse(html);

        const rawIngredients = data.ingredients;
        const title = data.title;

        if (!rawIngredients || rawIngredients.length === 0) {
            showNoRecipe();
            tabRecipeCache.delete(tab.id);
            return;
        }

        // Convert raw ingredients to AFX format
        const ingredients = rawIngredients.map(ing => parseIngredientForAFX(ing));

        currentIngredients = ingredients;
        currentRecipeTitle = title;
        displayIngredients(ingredients, title);
        recipeUrlInput.value = tab.url;

        tabRecipeCache.set(tab.id, {
            url: tab.url,
            ingredients: ingredients,
            title: title
        });

    } catch (error) {
        console.error('Auto-parse error:', error);
        showNoRecipe();
    }
}

function showLoadingState() {
    recipeTitle.classList.add('hidden');
    noRecipe.classList.add('hidden');
    ingredientList.innerHTML = '<div style="text-align: center; padding: 20px; color: #999;">🔍 Looking for recipe...</div>';
}

function showNoRecipe() {
    recipeTitle.classList.add('hidden');
    ingredientList.innerHTML = '';
    noRecipe.classList.remove('hidden');
    currentIngredients = null;
    currentRecipeTitle = '';
}

function displayIngredients(ingredients, title) {
    noRecipe.classList.add('hidden');

    if (title) {
        recipeTitle.textContent = title;
        recipeTitle.classList.remove('hidden');
    } else {
        recipeTitle.classList.add('hidden');
    }

    ingredientList.innerHTML = '';

    ingredients.forEach(ing => {
        const item = document.createElement('div');
        item.className = 'ingredient-item';

        const quantity = ing.quantityList[0];
        const quantityText = `${quantity.amount} ${quantity.unit.toLowerCase()}`;

        item.innerHTML = `<span class="ingredient-quantity">${quantityText}</span> ${ing.name}`;
        ingredientList.appendChild(item);
    });
}

function showUrlInput() {
    urlInputGroup.classList.add('show');
}

async function handleGetCurrentUrl() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab && tab.url) {
            recipeUrlInput.value = tab.url;
            showStatus('URL loaded from current page', 'success');
            setTimeout(() => hideStatus(), 2000);
        }
    } catch (error) {
        showStatus('Error getting current page URL', 'error');
    }
}

async function handleAddToCart() {
    if (currentIngredients && currentIngredients.length > 0) {
        submitToStore();
        return;
    }

    const url = recipeUrlInput.value.trim();

    if (!url) {
        showStatus('Please enter a recipe URL', 'error');
        showUrlInput();
        return;
    }

    try {
        new URL(url);
    } catch (error) {
        showStatus('Please enter a valid URL', 'error');
        return;
    }

    addToCartBtn.disabled = true;
    addToCartBtn.textContent = 'Parsing Recipe...';
    showLoadingState();

    try {
        let html;
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        // If URL matches active tab, leverage injection
        if (tab && tab.url === url) {
            html = await getTabHtml(tab.id);
        } else {
            // Otherwise try fetch (might fail CORS)
            try {
                const response = await fetch(url);
                if (response.ok) {
                    html = await response.text();
                } else {
                    throw new Error('Failed to fetch URL');
                }
            } catch (e) {
                throw new Error('Cannot parse external URL. Please navigate to the page.');
            }
        }

        if (!html) {
            throw new Error('Failed to retrieve page content');
        }

        // Use JavaScript parser
        const parser = new RecipeParser();
        const data = await parser.parse(html);

        const rawIngredients = data.ingredients;
        const title = data.title;

        if (!rawIngredients || rawIngredients.length === 0) {
            throw new Error('No ingredients found in recipe');
        }

        // Convert raw ingredients to AFX format
        const ingredients = rawIngredients.map(ing => parseIngredientForAFX(ing));

        // Store and display ingredients
        currentIngredients = ingredients;
        currentRecipeTitle = title;
        displayIngredients(ingredients, title);

        // Submit to store
        submitToStore();

    } catch (error) {
        console.error('Error:', error);
        showStatus(`Error: ${error.message}`, 'error');
        showNoRecipe();
        addToCartBtn.disabled = false;
        addToCartBtn.textContent = 'Add to Cart';
    }
}

function submitToStore() {
    if (!currentIngredients || currentIngredients.length === 0) {
        showStatus('No ingredients to add', 'error');
        return;
    }

    const storeName = selectedStore === 'wholefoods' ? 'Whole Foods' : 'Amazon Fresh';

    showStatus(`Sending ${currentIngredients.length} ingredients to ${storeName}...`, 'success');

    window.submitToAFX(currentIngredients, selectedStore, currentRecipeTitle);

    addToCartBtn.textContent = `✓ Sent to ${storeName}!`;
    addToCartBtn.disabled = true;

    setTimeout(() => {
        addToCartBtn.disabled = false;
        addToCartBtn.textContent = 'Add to Cart';
        hideStatus();
    }, 3000);
}

function showStatus(message, type) {
    statusDiv.className = `status ${type}`;

    if (type === 'loading') {
        statusDiv.innerHTML = `<span class="spinner"></span>${message}`;
    } else {
        statusDiv.textContent = message;
    }

    statusDiv.classList.remove('hidden');
}

function hideStatus() {
    statusDiv.classList.add('hidden');
}
